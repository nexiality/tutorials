INSERT INTO NORTH_AMERICA_COMPANIES VALUES ('${description}', '${address} ${city}, ${state} ${zipCode}');
