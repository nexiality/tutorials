INSERT INTO AVAILABLE_SONGS VALUES ('${artist name}', '${album}', '[TEXT(${song title}) => replace(','')]', '${unit price}', '$(sysdate|now|yyyy-MM-dd HH:mm:ss)');
