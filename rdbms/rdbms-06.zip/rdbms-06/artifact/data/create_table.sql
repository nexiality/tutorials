CREATE TABLE IF NOT EXISTS web03example1 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    last_name varchar(50),
    first_name varchar(50),
    email varchar(50),
    due varchar(50),
    web_site varchar(50),
    action varchar(50)
);
