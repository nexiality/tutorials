-- nexial:rdbms-06
SELECT LAST_NAME AS "Last Name",
    FIRST_NAME   AS "First Name",
    EMAIL        AS "Email",
    DUE          AS "Due",
    WEB_SITE     AS "Web Site",
    ACTION       AS "Action"
FROM WEB03EXAMPLE1
;

-- nexial:rdbms-06-raw
SELECT *
FROM WEB03EXAMPLE1
ORDER BY ID DESC
;