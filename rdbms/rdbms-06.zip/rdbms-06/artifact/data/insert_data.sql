INSERT INTO WEB03EXAMPLE1 ("last_name", "first_name", "email", "due", "web_site", "action")
VALUES ('Smith', 'John', 'jsmith@gmail.com', '$50.00', 'http://www.jsmith.com', 'edit delete')
;

INSERT INTO WEB03EXAMPLE1 ("last_name", "first_name", "email", "due", "web_site", "action")
VALUES ('Bach', 'Frank', 'fbach@yahoo.com', '$51.00', 'http://www.frank.com', 'edit delete')
;

INSERT INTO WEB03EXAMPLE1 ("last_name", "first_name", "email", "due", "web_site", "action")
VALUES ('Doe', 'Jason', 'jdoe@hotmail.com', '$100.00', 'http://www.jdoe.com', 'edit delete')
;

INSERT INTO WEB03EXAMPLE1 ("last_name", "first_name", "email", "due", "web_site", "action")
VALUES ('Conway', 'Tim', 'tconway@earthlink.net', '$50.00', 'http://www.timconway.com', 'edit delete')
;
