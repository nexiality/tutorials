### Lab 9: Macros

### start-09 / scenario1
- use Lab 6 as a starting point. Rewrite the "file content" activity into a macro
  - create the macro for maximum flexibility
  - how do we create "default" value when the expected data variable is not defined?

### start-09 / scenario
- use Lab 7 as a starting point.
  - how could you use macro to simplify the automation while maintain functional parity?
  
