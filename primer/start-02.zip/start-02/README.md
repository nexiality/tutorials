### Lab 2: Nexial batch utilities

#### start-02

##### nexial-project
- Windows:  `nexial-project.cmd  [PROJECT_NAME | C:\projects\PROJECT_NAME] [TEST FILE] [TEST FILE 2] … …`
- *NIX/Mac: `./nexial-project.sh [PROJECT_NAME | ~/projects/PROJECT_NAME]  [TEST FILE] [TEST FILE 2] … …`
- _Try re-running this script on existing project; Try running this script on non-standard project location_

##### nexial-crypt
- Windows:  `nexial-crypt.cmd  [PLAIN TEXT]`
- *NIX/Mac: `./nexial-crypt.sh [PLAIN TEXT]`
- use `start-02.xlsx` script, scenario `crypt`
- _What if we want to encrypt text with spaces or pipes? How are encrypted data represented in logs and output?_

##### nexial-script-update
- Windows:  `nexial-script-update.cmd  -t [%PROJECT_HOME%\artifact\script]`
- *NIX/Mac: `./nexial-script-update.sh -t [$PROJECT_HOME/artifact/script]`
- use `start-02.xlsx` script, scenario `crypt`
- _What if we want to update multiple projects?_

##### nexial-variable-update
- Windows:  `nexial-variable-update.cmd  -t [%PROJECT_HOME%\artifact] -d [var1=var2;var3=var4;...]`
- *NIX/Mac: `./nexial-variable-update.sh -t [$PROJECT_HOME/artifact]  -d [var1=var2;var3=var4;...]`
- use `start-02.xlsx` script, scenario `scenario2`
- _What about text files, SQL files or JSON files with old data variables? What if I want to review the changes before 
  committing to it?_

##### nexial
- Windows:  `nexial.cmd  –script [SCRIPT FILE]`
- *NIX/Mac: `./nexial.sh –script [SCRIPT FILE]`
- _What other options are available? How can I run a script with different data files or data sheets? What about test 
  plan?_
