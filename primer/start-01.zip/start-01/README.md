### Lab 1: Hello World

#### start-01
- "Hello World"
- Display basic system information
