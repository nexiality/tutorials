### Lab 7: Excel and CSV

#### lab-07 / scenario1
- using iteration to "create" the lyric of a song
- first introduction towards Flow Control
    - control based on ${os.name}
    - control based on last iteration

#### lab-07 / scenario2
- using iteration to perform simple mapreduce
- read 30 files to collect number of words and number of lines

#### lab-07 / scenario3
- same as above, but using base >> repeatUntil() to perform iteration
- much faster, but missing iteration-specific execution output

#### lab-07 / scenario4
- same as above, but using base >> section() to control a block of steps to skip
- shows the ability to skip over iteration based on data
- Flow Control example for "in a list of values"