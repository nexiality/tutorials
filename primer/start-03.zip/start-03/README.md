### Lab 3: Basics and Data Variable Overwrites

#### start-03 / scenario1
- base commands: print outs, assertions

#### start-03 / scenario2
- number commands : print outs, operations, assertions

#### start-03 / scenario3
- data variable overwrites

#### start-03 / scenario
- step commands
