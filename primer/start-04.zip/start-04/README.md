### Lab 4: Communication command basics

#### start-04 / scenario1
- base commands for list/array: assertion, append/prepend, split
- System variable: nexial.textDelim

#### start-04 / scenario2
- sound commands
  - _how to temporarily stop one of the commands?_
  - _how to randomly pick one of the prepackaged "sounds"?_
- quick intro to Flow Control
  - PauseBefore() / PauseAfter()
- sms command
- mail command
