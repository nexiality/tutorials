### Lab 5: Built-in Functions

#### start-05 / scenario1
- built-in functions: syspath, random, format, count
- run scenario1 from plan