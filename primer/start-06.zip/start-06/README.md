### Lab 6: Interactive and Inspection

#### start-06 / scenario1
- use Nexial Interactive and Inspection to develop script that answers the following questions:
  - How to express date/time as timestamp (millisecond expressed as integer)?
    - use `epoch` and `informal`
  - How to format date/time as day of the week?
    - `$(date|setDOW|${mydate}|0)`
  - How to sort the content of a file?
    - `$(file|asList|${output})`
  - How to select an item from a list?
    - `$(array|item|${content}|2)`
