### Lab 8: I/O commands

#### start-08 / scenario1
- display file metadata
- basic IO operations
- filter content out of text file
- comparison and matching

#### start-08 / scenario2
- excel data retrieval, multiple ways

#### start-08 / scenario1
- XML assertions and data extractions
